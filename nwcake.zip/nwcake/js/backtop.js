window.onload = function(){
            var backtop = document.getElementById("bt_but");
            var bt_time = null;
            var isTop = true;
            var clientHight = document.documentElement.clientHeight;
            
            window.onscroll = function() {
                var osTop = document.documentElement.scrollTop || document.body.scrollTop;
                
                if (osTop >= clientHight){
                    backtop.style.display = 'block';
                }else{
                    backtop.style.display = 'none';
                }
                if (!isTop){
                    clearInterval(bt_time);
                }
                isTop = false;
            }
            
            backtop.onclick = function(){
                bt_time = setInterval(function(){
                    var osTop = document.documentElement.scrollTop || document.body.scrollTop;
                    var ispeed = osTop/5;
                    
                    document.documentElement.scrollTop = document.body.scrollTop -= ispeed;
                    
                    isTop = true;
                    if (osTop == 0){
                        clearInterval(bt_time);
                    }
                },50);
            }
        }